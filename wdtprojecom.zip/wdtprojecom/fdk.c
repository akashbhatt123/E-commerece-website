#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

// Define the maximum number of items and their names
#define MAX_ITEMS 100
#define MAX_NAME_LENGTH 50

// Structure to store item information
struct Item {
    char name[MAX_NAME_LENGTH];
    double price;
};

// Function to display item menu and return selected item index
int displayMenu(struct Item items[], int itemCount) {
    printf("Available Items:\n");
    for (int i = 0; i < itemCount; i++) {
        printf("%d. %s - $%.2f\n", i + 1, items[i].name, items[i].price);
    }

    int choice;
    printf("Enter item number (1-%d): ", itemCount);
    scanf("%d", &choice);

    if (choice < 1 || choice > itemCount) {
        printf("Invalid choice. Please enter a valid item number.\n");
        return -1;
    }

    return choice - 1;
}

int main() {
    struct Item items[MAX_ITEMS];
    int itemCount;

    // Initialize items (you can add more items)
    strcpy(items[0].name, "T-Shirt");
    items[0].price = 15.99;
    
    strcpy(items[1].name, "Jeans");
    items[1].price = 29.99;

    itemCount = 2;

    double totalCost = 0.0;
    bool continueShopping = true;

    while (continueShopping) {
        int selectedItemIndex = displayMenu(items, itemCount);

        if (selectedItemIndex != -1) {
            totalCost += items[selectedItemIndex].price;
            printf("Added %s to the cart. Current total: $%.2f\n", items[selectedItemIndex].name, totalCost);
        }

        printf("Do you want to continue shopping? (1 for Yes, 0 for No): ");
        int continueChoice;
        scanf("%d", &continueChoice);

        if (continueChoice == 0) {
            continueShopping = false;
        }
    }

    printf("Final total: $%.2f\n", totalCost);
    
    return 0;
}
